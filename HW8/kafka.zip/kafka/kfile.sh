/usr/hdp/current/kafka-broker/bin/connect-standalone.sh ./connect-standalone.properties ./connect-file-source.properties ./connect-file-sink.properties


