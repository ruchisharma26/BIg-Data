/usr/hdp/current/kafka-broker/bin/kafka-topics.sh --list --zookeeper sandbox-hdp.hortonworks.com:2181

