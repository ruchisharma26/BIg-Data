nc -l sandbox-hdp.hortonworks.com 3333

