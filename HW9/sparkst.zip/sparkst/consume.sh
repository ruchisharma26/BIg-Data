/usr/hdp/current/spark2-client/bin/spark-submit ./consume.py

